# Ponts d'interopérabilité SQUELETTE

Ces trois fichiers sont le **cœur d'interop** du Protocole SQUELETTE. Ils
connectent les trois langages sans copie mémoire. Ce sont des **squelettes**
(la chair — l'implémentation des backends — est à remplir par des modules
déterministes, conformément au protocole).

## 1. `dlpack.h` — le pont tensoriel zéro-copie

Standard ouvert ([dmlc/dlpack](https://github.com/dmlc/dlpack)). Un tenseur
créé en JAX est exposé comme un `DLTensor*` que C++ et Rust peuvent lire et
écrire **sans copie**. C'est l'interface minimale commune aux trois langages.

- `DLTensor` : `{void* data, DLDevice, int ndim, DLDataType, int64_t* shape, int64_t* strides, uint64_t byte_offset}`
- `DLDataType` : `{code (Int/UInt/Float/Bfloat), bits (8/16/32/64), lanes}`

**C'est réel** — pas un squelette. Tu peux l'inclure tel quel dans un build C++.

## 2. `tvm_ffi.h` — l'ABI cœur (Apache TVM FFI)

Référence : [apache/tvm/ffi](https://github.com/apache/tvm/tree/main/ffi).
Expose des fonctions C++ (enregistrées par nom) appelables depuis Rust et JAX
via une ABI minimale. Les arguments passent par une union `TVMValue` dont le
cas `v_tensor` pointe vers un `DLTensor*`.

**Squelette** : l'API (`tvm_ffi_register`, `tvm_ffi_call`, `tvm_ffi_get_tensor`)
est déclarée. L'implémentation (registry thread-safe, marshalling des
`type_codes`, backends CPU/CUDA/Vulkan) est à écrire dans un module déterministe.

## 3. `enzyme_jax.py` — l'autodiff C++ ↔ JAX

Référence : [dmlc/enzyme-jax](https://github.com/dmlc/enzyme-jax). Permet à
du code C++ (exposé via TVM FFI) d'être **différencié automatiquement** depuis
JAX : Enzyme génère le code dérivé au niveau MLIR, tu n'écris pas le gradient.

**Squelette** : le décorateur `@enzyme_jit("cpp_fn_name")` est déclaré, mais
lève `NotImplementedError` tant que le binding MLIR n'est pas branché.

## Comment les relier (vue d'ensemble)

```
   JAX (Python)  ──DLPack──►  C++ (cœur TVM FFI)  ──FFI──►  Rust (sécurité)
        │                           │
        └──── Enzyme-JAX (MLIR autodiff) ────┘
```

1. JAX crée un tenseur → exposé en `DLTensor*` (DLPack).
2. C++ lit/écrit ce tenseur via une fonction enregistrée par `tvm_ffi_register`.
3. Rust appelle la même fonction C++ via FFI (`extern "C"`).
4. Enzyme dérive automatiquement le code C++ pour JAX (`jax.grad` marche).
