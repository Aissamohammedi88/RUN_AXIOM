"""Enzyme-JAX — pont d'autodiff C++ <-> JAX via MLIR (SQUELETTE).

Référence : https://github.com/dmlc/enzyme-jax
Rôle dans SQUELETTE : permettre à du code C++ (le cœur, exposé via TVM FFI)
d'être différencié automatiquement depuis JAX, sans que l'utilisateur n'écrive
le gradient à la main. Enzyme génère le code dérivé au niveau MLIR.

ATTENTION : ce fichier est le SQUELETTE. La chair (le plumbing MLIR, le
binding de primitive, les passes Enzyme) est à implémenter dans un module
déterministe — conformément au Protocole SQUELETTE.
"""
from __future__ import annotations
import jax


def enzyme_jit(cpp_fn_name: str):
    """Décorateur squelette.

    Wrap un appel C++ (exposé via TVM FFI sous ``cpp_fn_name``) en une
    primitive JAX *différentiable* grâce à Enzyme.

    Usage prévu (une fois la chair implémentée) :

        @enzyme_jit("process_data")
        def process_data(x: jax.Array) -> jax.Array:
            ...  # appel FFI vers le C++

        grad_fn = jax.grad(process_data)   # Enzyme fournit le gradient C++

    SQUELETTE : lève NotImplementedError tant que le binding MLIR n'est pas branché.
    """
    def decorator(fn):
        def wrapper(*args, **kwargs):
            # TODO SQUELETTE: enregistrer la primitive JAX branchée sur cpp_fn_name
            # via TVM FFI + la passe Enzyme MLIR. Voir README_bridges.md.
            raise NotImplementedError(
                "SQUELETTE: implémenter le binding Enzyme-JAX/MLIR pour "
                f"'{cpp_fn_name}' dans un module déterministe."
            )
        wrapper.__squelette_cpp_fn__ = cpp_fn_name
        wrapper.__doc__ = (fn.__doc__ or "") + "\n\n[Enzyme-JAX squelette — chair à implémenter]"
        return wrapper
    return decorator
