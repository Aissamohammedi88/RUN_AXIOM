// Apache TVM FFI — ABI d'interopérabilité zéro-copie (SQUELETTE structurel).
// Référence : https://github.com/apache/tvm/tree/main/ffi
// Rôle dans SQUELETTE : exposer des fonctions C++ (le cœur) à Rust et JAX
// via une ABI minimale, en passant des DLTensor* (DLPack) sans copie.
//
// ATTENTION : ceci est le SQUELETTE de l'interface. La chair (l'implémentation
// du registry, du marshalling type_codes, des threads) est à remplir par un
// module déterministe — conformément au Protocole SQUELETTE.
#ifndef TVM_FFI_H_
#define TVM_FFI_H_

#include "dlpack.h"

#ifdef __cplusplus
extern "C" {
#endif

// Code de type TVM (discriminant de l'union TVMValue)
typedef enum {
    kTVMNull = 0,
    kTVMInt = 1,
    kTVMFloat = 2,
    kTVMTensorHandle = 4,   // DLTensor*
    kTVMStr = 7,
    kTVMObjectHandle = 8,
} TVMTypeCode;

// Union de valeurs FFI (miroir de TVMValue côté Python)
typedef union {
    int64_t v_int64;
    double v_float64;
    void* v_handle;
    DLTensor* v_tensor;
    const char* v_str;
} TVMValue;

// Signature d'un callback FFI (compatible avec l'API TVM)
typedef int (*TVMFFICallbackFn)(TVMValue* args, int* type_codes, int num_args,
                                TVMValue* ret_value, int* ret_type_code);

// --- squelette d'API ---

// Enregistre une fonction C++ sous un nom logique (appelable depuis Rust/JAX).
int tvm_ffi_register(const char* name, TVMFFICallbackFn fn);

// Appelle une fonction enregistrée par nom.
int tvm_ffi_call(const char* name,
                 TVMValue* args, int* type_codes, int num_args,
                 TVMValue* ret_value, int* ret_type_code);

// Récupère un DLTensor partagé (zéro-copie) depuis un handle JAX/Rust.
// SQUELETTE : l'implémentation réelle dépend du backend (CPU/CUDA/Vulkan).
int tvm_ffi_get_tensor(void* jax_array_handle, DLTensor** out);

#ifdef __cplusplus
}
#endif
#endif  // TVM_FFI_H_
