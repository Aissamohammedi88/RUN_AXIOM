// DLPack 1.0 — ABI minimale pour tenseurs partagés ZÉRO-COPIE entre Python/JAX, C++ et Rust.
// Standard ouvert : https://github.com/dmlc/dlpack
// C'est le pont tensoriel du Protocole SQUELETTE : un tenseur créé en JAX
// peut être manipulé en C++ ou Rust sans copie mémoire.
#ifndef DLPACK_DLPACK_H_
#define DLPACK_DLPACK_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    kDLCPU = 1,
    kDLCUDA = 2,
    kDLOpenCL = 4,
    kDLROCM = 5,
    kDLVulkan = 7,
    kDLMetal = 8,
    kDLExtDev = 12
} DLDeviceType;

typedef struct {
    DLDeviceType device_type;
    int32_t device_id;
} DLDevice;

typedef enum {
    kDLInt = 0U,
    kDLUInt = 1U,
    kDLFloat = 2U,
    kDLBfloat = 4U,
    kDLFloat8_e3m4 = 8U
} DLDataTypeCode;

typedef struct {
    uint8_t code;     // DLDataTypeCode
    uint8_t bits;     // 8, 16, 32, 64
    uint16_t lanes;   // vecteur SIMD
} DLDataType;

typedef struct {
    void* data;
    DLDevice device;
    int32_t ndim;
    DLDataType dtype;
    int64_t* shape;
    int64_t* strides;    // NULL = compact row-major
    uint64_t byte_offset;
} DLTensor;

#ifdef __cplusplus
}
#endif
#endif  // DLPACK_DLPACK_H_
