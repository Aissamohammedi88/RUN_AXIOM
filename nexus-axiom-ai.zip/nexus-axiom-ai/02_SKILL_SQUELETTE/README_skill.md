# Dossier 2 — SKILL SQUELETTE (le protocole outillé)

L'implémentation déterministe du **Protocole SQUELETTE** : l'agent IA (dossier 1)
génère le **contrat** (structure), et ce dossier fournit le moteur qui produit
les **stubs** et les **valide**. La logique métier (la chair) n'est jamais ici.

## Le protocole en 4 étapes

```
prompt → [LLM NEXUS] → contract.json → [moteur déterministe] → stubs → [validator] → ✓/✗
```

1. **Contrat** : `nexus-skeleton.py` interroge le modèle NEXUS → obtient un
   `contract.json` validé contre `schema/contract.schema.json`.
2. **Stubs** : le moteur remplit les templates (`templates/`) de façon
   déterministe — un fichier vide par fonction. Corps `todo!()` / `pass` / `// TODO`.
3. **Validation** : `validator.py` vérifie que chaque stub contient la signature
   annoncée par le contrat. Échec → rejet.
4. **La chair** : à toi (ou à un module déterministe Rust/JAX/C++) d'implémenter.

## Contenu

| Chemin | Rôle |
|---|---|
| `schema/contract.schema.json` | Schéma JSON du contrat (validation structurelle). |
| `examples/contract.json` | Exemple : module `normalize_f32` (Rust). |
| `nexus-skeleton.py` | **Orchestrateur** : prompt → contrat → stubs → validation. |
| `validator.py` | Validateur déterministe des signatures. |
| `templates/` | `rust_stub.rs.tmpl`, `jax_stub.py.tmpl`, `cpp_tvm_stub.cpp.tmpl`. |
| `bridges/` | Ponts interop : `dlpack.h` (réel), `tvm_ffi.h` (squelette), `enzyme_jax.py` (squelette). |
| `banc_essai.sh` | Test de bout en bout (Ollama + identité + contrat + stubs + validation). |

## Usage

```bash
# 1) (une fois) installe le modèle : voir ../01_MODELE_NEXUS/install.sh

# 2) génère un module à partir d'un prompt
python3 nexus-skeleton.py "module Rust qui normalise un &[f32] en Vec<f32>"

# 3) valide des stubs contre un contrat
python3 validator.py examples/contract.json stubs/

# 4) banc d'essai complet
bash banc_essai.sh
```

Sortie typique : `out/contract.json` + `out/stubs/normalize.rs`, `mean.rs`, `stddev.rs`.

## Architecture cible (multi-langages)

```
   JAX (Python)  ──DLPack──►  C++ (cœur TVM FFI)  ──FFI──►  Rust (sécurité)
        │                           │
        └──── Enzyme-JAX (autodiff MLIR) ────┘
```

- **Rust** : sécurité mémoire / système (`fn ... -> Result<T, Error>`)
- **JAX** : calcul tensoriel + autodiff (`@jax.jit def f(x: jax.Array) -> jax.Array`)
- **C++** : cœur d'interop via **Apache TVM FFI** + **DLPack** (zéro-copie)
- **Enzyme-JAX** : autodiff du C++ dans JAX (via MLIR)

Voir `bridges/README_bridges.md` pour le détail des ponts.

## Ce que le LLM ne fait PAS

- N'écrit jamais la logique métier (algorithmes, calculs).
- Ne valide jamais la logique — seulement la structure.
- Ne réinvente pas l'architecture : il suit le contrat.

C'est toute la garantie du protocole : **le squelette avant la chair**, donc le
système ne ment jamais sur son architecture.
