#!/usr/bin/env python3
"""
NEXUS-AXIOM AI · Protocole SQUELETTE — orchestrateur
prompt utilisateur -> contrat JSON (via Ollama) -> stubs déterministes -> validation

Le LLM ne fait QUE le contrat (structure). Les stubs sont générés par templates
déterministes. La logique (la chair) n'est JAMAIS produite ici.
"""
import argparse, json, os, re, sys, urllib.request, urllib.error
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODELE_DIR = HERE.parent / "01_MODELE_NEXUS"
SYSTEM_PROMPT = (MODELE_DIR / "system_prompt.txt").read_text(encoding="utf-8")
SCHEMA_PATH = HERE / "schema" / "contract.schema.json"

EXT = {"Rust": "rs", "Python": "py", "JAX": "py", "C++": "cpp"}
TEMPLATE = {
    "Rust": HERE / "templates" / "rust_stub.rs.tmpl",
    "JAX": HERE / "templates" / "jax_stub.py.tmpl",
    "Python": HERE / "templates" / "jax_stub.py.tmpl",
    "C++": HERE / "templates" / "cpp_tvm_stub.cpp.tmpl",
}

# --- Ollama chat ---
def ollama_chat(host: str, model: str, user_prompt: str, num_predict: int = 400) -> str:
    payload = {
        "model": model,
        "stream": False,
        "options": {"num_predict": num_predict, "temperature": 0.2, "num_ctx": 4096},
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    }
    req = urllib.request.Request(
        f"{host}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.URLError as e:
        die(f"Ollama injoignable sur {host} : {e}. Lance 'ollama serve'.")
    except Exception as e:
        die(f"Erreur Ollama : {e}")
    if "error" in data:
        die(f"Ollama a renvoyé une erreur : {data['error']}")
    return data.get("message", {}).get("content", "")

# --- extraction JSON (retourne dict ou None, ne crash pas) ---
def extract_json(text: str):
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    raw = m.group(1) if m else text
    if not m:
        s = raw.find("{")
        e = raw.rfind("}")
        if s == -1 or e == -1:
            print(f"  ✗ aucun JSON trouvé dans la réponse")
            return None
        raw = raw[s:e+1]
    try:
        return json.loads(raw)
    except json.JSONDecodeError as ex:
        print(f"  ✗ JSON invalide : {ex}")
        return None

# --- validation contre schéma (retourne bool, ne crash pas) ---
def validate_contract(c: dict) -> bool:
    try:
        import jsonschema
        from jsonschema import ValidationError
        schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
        try:
            jsonschema.validate(c, schema)
            print("  ✓ contrat valide (jsonschema)")
            return True
        except ValidationError as e:
            path = "/".join(str(p) for p in e.absolute_path) or "(racine)"
            print(f"  ✗ contrat invalide : {e.message}  [chemin: {path}]")
            return False
    except ImportError:
        for k in ("name", "language", "inputs", "outputs", "functions"):
            if k not in c:
                print(f"  ✗ contrat invalide : champ '{k}' manquant")
                return False
        if c["language"] not in EXT:
            print(f"  ✗ contrat invalide : language '{c['language']}' non supporté")
            return False
        print("  ✓ contrat valide (validation minimale — installe jsonschema pour validation complète)")
        return True

# --- génération déterministe des stubs ---
def generate_stubs(c: dict, out_dir: Path) -> list:
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for fn in c.get("functions", []):
        lang = fn.get("lang") or c["language"]
        if lang not in TEMPLATE:
            print(f"  ! lang '{lang}' pour {fn['name']} — ignoré")
            continue
        tmpl = TEMPLATE[lang].read_text(encoding="utf-8")
        code = tmpl.format(module_name=c["name"], signature=fn["signature"])
        ext = EXT[lang]
        path = out_dir / f"{fn['name']}.{ext}"
        path.write_text(code, encoding="utf-8")
        written.append((fn["name"], lang, path))
        try:
            disp = path.relative_to(HERE.parent)
        except ValueError:
            disp = path
        print(f"  ✓ stub : {disp}  [{lang}]")
    return written

def die(msg: str):
    print(f"✗ {msg}", file=sys.stderr)
    sys.exit(1)

def main():
    ap = argparse.ArgumentParser(description="NEXUS-AXIOM AI · orchestrateur SQUELETTE")
    ap.add_argument("prompt", nargs="?", help="Description du module à scaffolder (omis si --contract)")
    ap.add_argument("--contract", help="Charger un contract.json existant (mode 100%% déterministe, sans LLM)")
    ap.add_argument("--model", default="nexus-axiom-ai", help="Modèle Ollama (défaut: nexus-axiom-ai ; lite sur machine peu de RAM)")
    ap.add_argument("--host", default="http://127.0.0.1:11434", help="Hôte Ollama")
    ap.add_argument("--out", default="out", help="Dossier de sortie (contract.json + stubs/)")
    args = ap.parse_args()

    if not args.contract and not args.prompt:
        ap.error("fournis un prompt, ou --contract <fichier>")

    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    print(f"════ NEXUS-AXIOM AI · SQUELETTE ════")
    if args.contract:
        print(f"[1/4] contrat chargé (mode déterministe) : {args.contract}")
        c = json.loads(Path(args.contract).read_text(encoding="utf-8"))
        print(f"[2/4] validation du contrat")
        if not validate_contract(c):
            die("contrat fourni invalide — corrige-le ou régénère sans --contract")
    else:
        print(f"[1/4] prompt → contrat  (modèle: {args.model})")
        user_msg = (
            "Génère un contract.json pour la demande suivante. "
            "Réponds avec UNIQUEMENT le JSON valide (ou un bloc ```json), "
            "respectant les champs: name, description, language, inputs[], outputs[], functions[]. "
            "Chaque function a: name, signature, return_type, lang. "
            "La signature DOIT être complète et inclure le type de retour, "
            "ex: \"fn normalize(v: &[f32]) -> Result<Vec<f32>, NormError>\". "
            "Ne mets AUCUNE logique dans les stubs.\n\n"
            f"Demande : {args.prompt}"
        )
        c = None
        for attempt in (1, 2):
            extra = "" if attempt == 1 else "\n\n(2e essai : réponds avec un JSON STRICT, uniquement les clés du schéma.)"
            raw = ollama_chat(args.host, args.model, user_msg + extra)
            cand = extract_json(raw)
            if cand is None:
                continue
            print(f"  ✓ JSON extrait (essai {attempt}/2) — validation…")
            if validate_contract(cand):
                c = cand
                break
        if c is None:
            die("échec génération du contrat après 2 essais — relance, ou utilise --contract <fichier>")

    (out / "contract.json").write_text(json.dumps(c, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  ✓ contrat écrit : {out/'contract.json'}")

    print(f"[3/4] génération déterministe des stubs")
    stubs_dir = out / "stubs"
    written = generate_stubs(c, stubs_dir)

    print(f"[4/4] validation des stubs")
    import subprocess
    if written:
        r = subprocess.run(
            [sys.executable, str(HERE / "validator.py"), str(out / "contract.json"), str(stubs_dir)],
            capture_output=True, text=True)
        print(r.stdout.rstrip() if r.stdout else "  (validator sans sortie)")
        if r.returncode != 0:
            print(f"  ⚠ validator a signalé des écarts (exit {r.returncode})", file=sys.stderr)
    else:
        print("  ⚠ aucun stub généré — rien à valider")
    print(f"════ terminé : {len(written)} stub(s) dans {stubs_dir} ════")

if __name__ == "__main__":
    main()
