#!/usr/bin/env python3
"""
NEXUS-AXIOM AI · SQUELETTE — validateur déterministe
Vérifie que chaque stub contient bien la signature annoncée par le contrat.
Valide la STRUCTURE, jamais la logique.
"""
import json, re, sys
from pathlib import Path

EXT = {"Rust": "rs", "Python": "py", "JAX": "py", "C++": "cpp"}

def main():
    if len(sys.argv) < 3:
        print("usage: validator.py <contract.json> <stubs_dir>", file=sys.stderr)
        sys.exit(2)
    contract_path, stubs_dir = Path(sys.argv[1]), Path(sys.argv[2])
    c = json.loads(contract_path.read_text(encoding="utf-8"))
    stubs_dir = stubs_dir.resolve()

    funcs = c.get("functions", [])
    if not funcs:
        print("⚠ contrat sans fonctions — rien à valider")
        sys.exit(0)

    ok = 0; ko = 0
    for fn in funcs:
        lang = fn.get("lang") or c.get("language", "Rust")
        ext = EXT.get(lang, "rs")
        path = stubs_dir / f"{fn['name']}.{ext}"
        name = fn["name"]
        ret = fn.get("return_type", "")
        issues = []
        if not path.exists():
            issues.append(f"stub manquant : {path.name}")
        else:
            txt = path.read_text(encoding="utf-8")
            # signature présente ? on cherche le nom de fonction + type de retour
            if name not in txt:
                issues.append(f"nom de fonction '{name}' absent du stub")
            # extraire les tokens clés du return_type et vérifier leur présence dans la signature (1ère ligne non-commentaire non-vide)
            sig_tokens = [t for t in re.split(r"[<>,()\s>&;\[\]:]+", ret) if t and t not in ("Result",)]
            first_sig = next((l for l in txt.splitlines() if l.strip() and not l.strip().startswith(("//", "#"))), "")
            missing = [t for t in sig_tokens if t and t not in first_sig]
            # tolérant: si la 1ère ligne signature manque des tokens, on regarde tout le fichier
            if missing:
                missing = [t for t in missing if t not in txt]
            if missing:
                issues.append(f"tokens du return_type manquants : {missing}")
        if issues:
            print(f"✗ {name} : {' ; '.join(issues)}")
            ko += 1
        else:
            print(f"✓ {name} : signature conforme au contrat")
            ok += 1

    print(f"\nRÉSUMÉ : {ok} OK / {ko} KO sur {len(funcs)} fonction(s)")
    sys.exit(0 if ko == 0 else 1)

if __name__ == "__main__":
    main()
