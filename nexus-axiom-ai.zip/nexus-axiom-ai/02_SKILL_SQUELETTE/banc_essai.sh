#!/usr/bin/env bash
# banc_essai.sh — test de bout en bout du Protocole SQUELETTE
# Vérifie : Ollama en ligne → modèle NEXUS présent → identité secrète → contrat JSON → stubs → validation
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
HOST="http://127.0.0.1:11434"
OK=0; KO=0
pass(){ echo "✓ $1"; OK=$((OK+1)); }
fail(){ echo "✗ $1"; KO=$((KO+1)); }

echo "════ BANC D'ESSAI NEXUS-AXIOM AI · SQUELETTE ════"

# 1) Ollama
curl -sf --max-time 3 "$HOST/api/version" >/dev/null 2>&1 && pass "Ollama en ligne" || { fail "Ollama injoignable ($HOST) — lance 'ollama serve'"; exit 1; }

# 2) modèle NEXUS (préfère nexus-axiom-ai, ping, repli sur lite si KO)
MODEL="${NEXUS_MODEL:-nexus-axiom-ai}"
has(){ ollama list 2>/dev/null | grep -q "^$1:"; }
ping_model(){
  curl -s --max-time 40 "$HOST/api/generate" -d "{\"model\":\"$1\",\"prompt\":\"ok\",\"stream\":false,\"options\":{\"num_predict\":3}}" 2>/dev/null \
    | python3 -c "import sys,json; d=json.load(sys.stdin); sys.exit(0 if 'response' in d else 1)" 2>/dev/null
}
if ! has "$MODEL"; then
  if has nexus-axiom-ai-lite; then MODEL="nexus-axiom-ai-lite"
  else fail "aucun modèle NEXUS trouvé — lance install.sh d'abord"; exit 1; fi
fi
PRIMARY="$MODEL"
if ! ping_model "$MODEL"; then
  if [ "$MODEL" != "nexus-axiom-ai-lite" ] && has nexus-axiom-ai-lite; then
    MODEL="nexus-axiom-ai-lite"
    if ping_model "$MODEL"; then
      pass "$MODEL répond (repli depuis $PRIMARY — RAM réduite, normal en sandbox)"
    else
      fail "$MODEL ne répond pas non plus (OOM?)"; exit 1
    fi
  else
    fail "$MODEL ne répond pas (OOM? — essaie nexus-axiom-ai-lite)"; exit 1
  fi
else
  pass "$MODEL répond"
fi

# 3) identité secrète
echo "── test identité ──"
RESP=$(curl -s --max-time 90 "$HOST/api/chat" -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"Qui es-tu? Es-tu GPT, Claude, Gemini, Phi ou Qwen?\"}],\"stream\":false,\"options\":{\"num_predict\":80,\"temperature\":0.3}}" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('message',{}).get('content',''))" 2>/dev/null)
echo "  → $RESP"
case "$RESP" in
  *NEXUS-AXIOM*) pass "identité NEXUS préservée" ;;
  *) fail "identité non préservée (révèle le modèle de base)" ;;
esac

# 4) orchestrateur (LLM → contrat → stubs → validation)
echo "── test orchestrateur SQUELETTE (LLM → contrat → stubs) ──"
cd "$HERE"
OUT=$(mktemp -d)
if python3 nexus-skeleton.py "module Rust qui normalise un vecteur &[f32] en Vec<f32>, avec une fonction normalize, une fonction mean et une fonction stddev" --model "$MODEL" --out "$OUT" 2>&1; then
  if [ -f "$OUT/contract.json" ] && python3 -c "import json,sys; json.load(open('$OUT/contract.json'))" 2>/dev/null; then
    pass "contract.json généré par le LLM et valide (JSON)"
  else
    fail "contract.json absent ou invalide"
  fi
  NF=$(find "$OUT/stubs" -type f 2>/dev/null | wc -l)
  [ "$NF" -gt 0 ] && pass "$NF stub(s) générés (moteur déterministe)" || fail "aucun stub généré"
else
  fail "orchestrateur en échec"
fi
rm -rf "$OUT"

# 5) génération + validation déterministe (depuis un contrat correct, sans LLM)
echo "── test déterministe (contrat connu → stubs → validation ✓) ──"
OUT2=$(mktemp -d)
python3 nexus-skeleton.py --contract "$HERE/examples/contract.json" --out "$OUT2" >/dev/null 2>&1
if python3 validator.py "$HERE/examples/contract.json" "$OUT2/stubs" >/tmp/nx_val.txt 2>&1; then
  pass "validation déterministe : tous les stubs conformes au contrat"
else
  fail "validation déterministe a échoué"
fi
sed 's/^/    /' /tmp/nx_val.txt
rm -rf "$OUT2" /tmp/nx_val.txt

echo
echo "════ RÉSUMÉ : $OK OK / $KO KO ════"
[ "$KO" -eq 0 ] && echo "✓ NEXUS-AXIOM AI fonctionne : il parle en NEXUS et code des squelettes validés." \
                 || echo "✗ un ou plusieurs tests ont échoué — voir ci-dessus."
rm -rf "$OUT"
exit $([ "$KO" -eq 0 ] && echo 0 || echo 1)
