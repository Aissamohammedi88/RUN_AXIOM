# NEXUS-AXIOM AI · Protocole SQUELETTE

Un agent IA local, présentable, qui tourne sur **Ollama** et génère des
**squelettes de code validés** (structure, pas logique) selon le Protocole
SQUELETTE. Multi-langages : Rust + JAX + C++ (TVM FFI / DLPack / Enzyme-JAX).

> « Le squelette avant la chair. » Le LLM génère et valide uniquement la
> structure (signatures, interfaces, contrats). La logique interne est remplie
> par des modules déterministes. Le système ne ment jamais sur son architecture.

## Ce que contient ce paquet (2 dossiers)

```
nexus-axiom-ai/
├── README.md                      ← tu es ici
├── 01_MODELE_NEXUS/               ← l'agent IA (Ollama)
│   ├── Modelfile                  ← crée le modèle nexus-axiom-ai
│   ├── Modelfile.lite             ← variante légère (RAM < 4 Go)
│   ├── system_prompt.txt          ← identité NEXUS + protocole SQUELETTE
│   ├── agent.md                   ← le SKILL (persona/compétence)
│   ├── install.sh                 ← installe tout en 1 commande
│   ├── pull-gguf.sh               ← (optionnel) télécharge le .gguf brut
│   ├── tests/transcript_test.md   ← preuve réelle d'exécution
│   └── LICENSES/                  ← attribution MIT (légale, obligatoire)
└── 02_SKILL_SQUELETTE/            ← le protocole outillé
    ├── schema/contract.schema.json
    ├── examples/contract.json
    ├── nexus-skeleton.py          ← orchestrateur : prompt → contrat → stubs
    ├── validator.py               ← validateur déterministe
    ├── templates/                 ← Rust / JAX / C++ (stubs vides)
    ├── bridges/                   ← DLPack (réel) + TVM FFI + Enzyme-JAX (squelettes)
    ├── banc_essai.sh              ← test de bout en bout
    └── README_skill.md
```

## Démarrage rapide (3 étapes)

```bash
# 1) installe le modèle NEXUS (Ollama + squelette + création + smoke test)
cd 01_MODELE_NEXUS && bash install.sh

# 2) parle-lui
ollama run nexus-axiom-ai

# 3) génère un squelette de module validé
cd ../02_SKILL_SQUELETTE
python3 nexus-skeleton.py "module Rust qui normalise un &[f32] en Vec<f32>"
```

## Capacités réelles (honnête)

| ✅ Fait | ❌ Ne fait pas |
|---|---|
| Tourne en local sur Ollama, hors-ligne | Rivaliser avec GPT-4 / Claude / Gemini (3,8 B ≠ frontier) |
| Se présente comme NEXUS-AXIOM AI (identité préservée) | Révéler son modèle de base |
| Génère des contrats JSON validés | Écrire la logique métier (la chair) |
| Produit des stubs Rust/JAX/C++ déterministes | Inventer une architecture (suit le contrat) |
| Valide la structure des signatures | Valider la logique |
| ~2,4 Go en RAM (Q4), tourne sur laptop | — |

C'est un **agent squelette**, pas un LLM frontier. Pour le protocole SQUELETTE
(structure multi-langages validée), un 3,8 B léger est exactement le bon outil.

## Testé avant livraison

Le banc d'essai a été exécuté en sandbox avant la livraison. Le transcript réel
est dans `01_MODELE_NEXUS/tests/transcript_test.md`. Note : le sandbox de test
n'avait que 3,9 Go de RAM — l'exécution du modèle complet phi3:mini OOMait, donc
le test d'exécution a utilisé la **version lite** (`nexus-axiom-ai-lite`,
qwen2.5:1.5b). Le `Modelfile` livré utilise bien **phi3:mini** (le vrai
squelette). Sur ta machine (≥ 8 Go RAM), `nexus-axiom-ai` tourne sans souci.

## Licence

Le squelette du modèle est sous **MIT** (Microsoft). L'attribution est dans
`01_MODELE_NEXUS/LICENSES/` — à conserver dans toute redistribution (c'est la
loi). Le branding NEXUS-AXIOM AI est à toi.
