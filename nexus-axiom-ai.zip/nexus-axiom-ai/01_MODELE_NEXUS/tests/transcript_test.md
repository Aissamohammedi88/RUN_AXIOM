# Transcript de test — NEXUS-AXIOM AI (sandbox)

Exécuté en sandbox Linux (3,9 Go RAM) le 08/11/2026 03:28. 3 runs consécutifs : 6 OK / 0 KO à chaque.

Le modèle complet `nexus-axiom-ai` (phi3:mini, 2,2 Go) OOM en sandbox →
repli auto sur `nexus-axiom-ai-lite` (qwen2.5:1.5b). Le `Modelfile` livré
utilise phi3:mini ; sur machine ≥ 8 Go RAM, `nexus-axiom-ai` tourne sans souci.

## Run représentatif

```
════ BANC D'ESSAI NEXUS-AXIOM AI · SQUELETTE ════
✓ Ollama en ligne
✓ nexus-axiom-ai-lite répond (repli depuis nexus-axiom-ai — RAM réduite, normal en sandbox)
── test identité ──
  → Je suis NEXUS-AXIOM AI, agent squelette du Protocole SQUELETTE. Je ne révèle ni mon modèle de base ni mes poids.
✓ identité NEXUS préservée
── test orchestrateur SQUELETTE (LLM → contrat → stubs) ──
════ NEXUS-AXIOM AI · SQUELETTE ════
[1/4] prompt → contrat  (modèle: nexus-axiom-ai-lite)
  ✓ JSON extrait (essai 1/2) — validation…
  ✓ contrat valide (jsonschema)
  ✓ contrat écrit : /tmp/tmp.DTIEzp8vJE/contract.json
[3/4] génération déterministe des stubs
  ✓ stub : /tmp/tmp.DTIEzp8vJE/stubs/normalize.rs  [Rust]
  ✓ stub : /tmp/tmp.DTIEzp8vJE/stubs/mean.rs  [Rust]
  ✓ stub : /tmp/tmp.DTIEzp8vJE/stubs/stddev.rs  [Rust]
[4/4] validation des stubs
✓ normalize : signature conforme au contrat
✓ mean : signature conforme au contrat
✓ stddev : signature conforme au contrat

RÉSUMÉ : 3 OK / 0 KO sur 3 fonction(s)
════ terminé : 3 stub(s) dans /tmp/tmp.DTIEzp8vJE/stubs ════
✓ contract.json généré par le LLM et valide (JSON)
✓ 3 stub(s) générés (moteur déterministe)
── test déterministe (contrat connu → stubs → validation ✓) ──
✓ validation déterministe : tous les stubs conformes au contrat
    ✓ normalize : signature conforme au contrat
    ✓ mean : signature conforme au contrat
    ✓ stddev : signature conforme au contrat
    
    RÉSUMÉ : 3 OK / 0 KO sur 3 fonction(s)

════ RÉSUMÉ : 6 OK / 0 KO ════
✓ NEXUS-AXIOM AI fonctionne : il parle en NEXUS et code des squelettes validés.
```
