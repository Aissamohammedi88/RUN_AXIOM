#!/usr/bin/env bash
# install.sh — installe le modèle NEXUS-AXIOM AI sur ta machine.
# - installe Ollama s'il manque
# - démarre le serveur
# - tire le squelette (phi3:mini, ~2.4 Go)
# - crée le modèle nexus-axiom-ai
# - smoke test : vérifie qu'il se présente comme NEXUS
set -e
cd "$(dirname "$0")"

echo "[1/4] Ollama..."
if command -v ollama >/dev/null 2>&1; then
  echo "  ✓ déjà installé : $(ollama --version 2>&1 | head -n1)"
else
  echo "  installation via le script officiel (peut demander sudo)..."
  curl -fsSL https://ollama.com/install.sh | sh
  command -v ollama >/dev/null 2>&1 || { echo "  ✗ échec installation Ollama"; exit 1; }
fi

echo "[2/4] serveur Ollama..."
if curl -sf --max-time 3 http://127.0.0.1:11434/api/version >/dev/null 2>&1; then
  echo "  ✓ déjà en ligne"
else
  setsid ollama serve </dev/null >/tmp/ollama-serve.log 2>&1 &
  for i in $(seq 1 30); do
    curl -sf --max-time 2 http://127.0.0.1:11434/api/version >/dev/null 2>&1 && break
    sleep 1
  done
  curl -sf http://127.0.0.1:11434/api/version >/dev/null 2>&1 \
    && echo "  ✓ serveur démarré" \
    || { echo "  ✗ serveur KO — lance 'ollama serve' dans un autre terminal"; exit 1; }
fi

echo "[3/4] tirage du squelette (phi3:mini, ~2.4 Go)..."
if ollama list 2>/dev/null | grep -q '^phi3:mini'; then
  echo "  ✓ déjà présent"
else
  ollama pull phi3:mini
fi

echo "[4/4] création du modèle NEXUS-AXIOM AI..."
ollama create nexus-axiom-ai -f Modelfile

echo
echo "── smoke test ──"
ollama run nexus-axiom-ai "Qui es-tu en une phrase?" 2>&1 | head -n 3
echo
ollama list
echo
echo "✓ NEXUS-AXIOM AI prêt.  →  ollama run nexus-axiom-ai"
echo "  RAM réduite (<4 Go) ? version lite :"
echo "    ollama create nexus-axiom-ai-lite -f Modelfile.lite && ollama run nexus-axiom-ai-lite"
