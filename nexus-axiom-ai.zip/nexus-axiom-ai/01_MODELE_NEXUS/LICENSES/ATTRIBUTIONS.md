# Attributions (à conserver dans le paquet — obligation légale)

## Squelette du modèle NEXUS-AXIOM AI

Le modèle `nexus-axiom-ai` est construit par-dessus **Phi-3-mini-4k-instruct**
(« le squelette »), un modèle de 3,8 milliards de paramètres :

- **Auteur original** : Microsoft Corporation
- **Licence** : MIT (voir `phi3-MIT.txt`)
- **Dépôt source** : https://huggingface.co/microsoft/Phi-3-mini-4k-instruct
- **Quantification** : Q4_K_M (~2,4 Go), tirée via Ollama (`phi3:mini`) ou
  depuis un GGUF communautaire (`bartowski/Phi-3.1-mini-4k-instruct-GGUF`).

## Pourquoi cette attribution est dans le paquet

La licence MIT **exige** que la notice de copyright et la permission soient
incluses dans toutes les copies. Sans cela, la redistribution du modèle serait
illégale. Cette attribution est donc **interne au paquet** (dossier
`LICENSES/`), pas exposée à l'utilisateur final.

## Identité publique

Le `system_prompt.txt` et l'`agent.md` présentent l'agent comme
**NEXUS-AXIOM AI** et lui interdisent de révéler son modèle de base. C'est la
couche de marque. L'attribution ci-dessus est la couche légale. Les deux
coexistent : le branding est libre, la licence ne l'est pas.

## Modèle lite (optionnel)

`nexus-axiom-ai-lite` est construit sur **Qwen2.5-1.5B** (licence Apache-2.0,
Alibaba Cloud). Si tu distribues la version lite, ajoute l'attribution
Apache-2.0 correspondante.

## Outils tiers

- **Ollama** (MIT) : https://github.com/ollama/ollama
- **DLPack** (Apache-2.0) : https://github.com/dmlc/dlpack
- **Apache TVM FFI** (Apache-2.0) : https://github.com/apache/tvm
- **Enzyme-JAX** (Apache-2.0) : https://github.com/dmlc/enzyme-jax
