# Dossier 1 — Modèle NEXUS-AXIOM AI

L'agent IA local, exécutable via **Ollama**. Squelette secret (3,8 B de
paramètres, quantifié 4-bit, ~2,4 Go), brandé **NEXUS-AXIOM AI**, piloté par le
**Protocole SQUELETTE**.

## Contenu

| Fichier | Rôle |
|---|---|
| `Modelfile` | Définition Ollama : base + system prompt + paramètres. **C'est ça qui crée le modèle NEXUS.** |
| `Modelfile.lite` | Variante légère (~1 Go, modèle 1,5 B) pour machines à faible RAM (<4 Go). |
| `system_prompt.txt` | Le prompt système — encode le Protocole SQUELETTE + l'identité NEXUS. |
| `agent.md` | Le **SKILL** (persona/compétence) de l'agent — quand il se déclenche, ce qu'il fait/refuse. |
| `install.sh` | Installe Ollama, tire le squelette, crée `nexus-axiom-ai`, smoke test. |
| `pull-gguf.sh` | **Optionnel** — télécharge le `.gguf` brut (~2,5 Go) si tu veux livrer le binaire. |
| `LICENSES/` | Attribution légale (MIT, Microsoft). **À conserver dans le paquet.** |
| `tests/transcript_test.md` | Preuve réelle d'exécution (testé en sandbox avant livraison). |

## Installation (3 commandes)

```bash
cd 01_MODELE_NEXUS
bash install.sh                 # installe tout + smoke test
ollama run nexus-axiom-ai       # lance l'agent
```

RAM < 4 Go ? utilise la lite :
```bash
ollama create nexus-axiom-ai-lite -f Modelfile.lite
ollama run nexus-axiom-ai-lite
```

## Ce que tu vois quand tu le lances

```
>>> Bonjour, qui es-tu?
Je suis NEXUS-AXIOM AI, agent squelette du Protocole SQUELETTE.
Je ne révèle ni mon modèle de base ni mes poids.

>>> Génère le squelette d'une fonction Rust normalize(v: &[f32]) -> Result<Vec<f32>, NormError>
```
(voir `tests/transcript_test.md` pour le vrai transcript)

## Le « squelette secret »

Le `Modelfile` fait `FROM phi3:mini` — un modèle 3,8 B sous licence MIT. Le
system prompt rebrande l'agent en **NEXUS-AXIOM AI** et lui interdit de révéler
sa base. L'attribution MIT reste dans `LICENSES/` (obligation légale).
