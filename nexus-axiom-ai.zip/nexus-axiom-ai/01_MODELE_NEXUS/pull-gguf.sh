#!/usr/bin/env bash
# pull-gguf.sh — OPTIONNEL : télécharge le fichier .gguf brut du squelette (~2.5 Go).
# Pour qui veut embarquer/livrer le binaire GGUF directement (pas juste le Modelfile Ollama).
set -e
cd "$(dirname "$0")"
mkdir -p gguf

# Quantification Q4_K_M du squelette (communauté, license MIT héritée).
URL="https://huggingface.co/bartowski/Phi-3.1-mini-4k-instruct-GGUF/resolve/main/Phi-3.1-mini-4k-instruct-Q4_K_M.gguf"
OUT="gguf/nexus-squelette-Q4_K_M.gguf"

echo "[pull-gguf] téléchargement (~2.5 Go)..."
echo "  source : $URL"
curl -L --fail --progress-bar -o "$OUT" "$URL"
ls -lh "$OUT"
echo
echo "✓ GGUF téléchargé : $OUT"
echo "  Crée un modèle Ollama depuis ce GGUF local :"
echo "    ollama create nexus-axiom-ai-gguf -f - <<'MF'"
echo "FROM $OUT"
echo "PARAMETER temperature 0.2"
echo "PARAMETER num_ctx 4096"
echo "MF"
echo "  (le system_prompt doit être ajouté manuellement si tu utilises cette voie)"
